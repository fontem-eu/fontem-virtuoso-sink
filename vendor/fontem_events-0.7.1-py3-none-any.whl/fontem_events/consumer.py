"""Consumer side of the event log.

A consumer is a long-lived process that:

  1. Reads its committed offset from ``events.consumer_offsets``.
  2. Fetches a window of events ``WHERE seq > offset`` (optionally
     bounded above by another consumer's offset for high-watermark
     gating).
  3. Hands the batch to ``handle()`` (subclass-supplied).
  4. Commits the new offset in the same Postgres transaction as the
     work — so a crash mid-handle causes a redo, not a loss.

Only a contiguous run of seqs is ever consumed. A seq is taken from
the sequence when a producer inserts, but the row becomes visible
when that producer commits, so a later seq can be committed while an
earlier one is still in flight. Reading ``seq > offset`` and
committing the highest seq seen would step over the in-flight one,
which nothing ever reads again: that lost 9,567 of 18,957 Kohesio
projects on 2026-09-28, loaded while two TED rescans committed
around each 1,000-project chunk. So a fetch stops at the first
missing seq and waits. A missing seq stops waiting once every
transaction that was running when the gap was first seen has ended:
from then on the row is visible if it was committed, and it was
rolled back if it is still missing (see ``_contiguous``).

Failures retry with backoff, and fall into two kinds.

A *poison* failure is deterministic and belongs to the event
itself — bad data no retry will fix. The whole batch is written
to ``events.dead_letter`` with an ``attempts`` counter, and when
the same first seq fails ``max_attempts`` times in a row the
consumer advances the offset past that single seq, logs loudly,
and keeps draining. The dead_letter row is the record of what
was skipped; the operator triages from there. This prevents one
bad event from jamming a consumer indefinitely — observed in
prod on 2026-06-09 when an un-escaped quote in an eu-cohesion
Disclosure description had the virtuoso_sink retrying the same
batch ~15,700 times over 66 hours.

A *retryable* failure is the downstream store being unreachable
or overloaded, and says nothing about the event. Subclasses
classify these by overriding ``is_retryable``. They retry
forever: the offset never advances, and nothing is written to
dead_letter. Skipping them is silent, permanent data loss —
``--since``-windowed ETL never re-emits a skipped event, so the
projection is simply wrong from then on. Observed in shared on
2026-09-06, when Virtuoso was OOM-killed during a replay and the
sink skipped 4,006 events in the outage window rather than
waiting for it to come back.

Observability:

  * Prometheus: ``event_lag_seconds``, ``events_processed_total``,
    ``events_failed_total``, ``batch_size``.
  * Uptime Kuma: heartbeat ping per loop iteration (default-down trap
    if the loop dies).
"""
from __future__ import annotations

import abc
import logging
import os
import time
from dataclasses import dataclass
from typing import Iterable

import psycopg
from fontem_event_schemas import EventEnvelope
from prometheus_client import Counter, Gauge, Histogram, start_http_server

from .errors import EventLogError, OffsetError

logger = logging.getLogger(__name__)

# Module-level Prometheus collectors so multiple EventConsumer
# instances (different consumer_names) coexist in the same
# process — instance-scoped collectors clash on the global
# default registry.
_EVENT_LAG_SECONDS = Gauge(
    "event_lag_seconds",
    "Seconds between newest event and last-processed seq",
    ["consumer"],
)
_EVENTS_PROCESSED_TOTAL = Counter(
    "events_processed_total",
    "Events successfully applied",
    ["consumer", "event_type"],
)
_EVENTS_FAILED_TOTAL = Counter(
    "events_failed_total",
    "Events that failed and went to DLQ",
    ["consumer", "event_type"],
)
_EVENT_BATCH_SIZE = Histogram(
    "event_batch_size",
    "Size of each handled batch",
    ["consumer"],
    buckets=[1, 10, 50, 100, 500, 1000, 5000],
)


@dataclass
class ConsumerConfig:
    name: str                           # 'virtuoso_sink', 'neo4j_sink', …
    dsn: str                            # Postgres DSN
    poll_interval_seconds: float = 5.0
    batch_size: int = 1000
    max_attempts: int = 5
    upstream_consumer: str | None = None  # high-watermark gating
    metrics_port: int | None = 9100
    kuma_push_url: str | None = None
    #: How long after first seeing a missing seq its horizon is taken.
    #: A producer takes its seq a moment before it is given a
    #: transaction id; by now every holder of the seq has one, so the
    #: horizon cannot miss it.
    gap_min_wait_seconds: float = 5.0
    #: ...and always passed after this, so a session left idle in a
    #: transaction cannot stall the consumer forever. Passing it then is
    #: logged as an error: if the seq was only slow, it is lost.
    gap_max_wait_seconds: float = 1800.0


@dataclass
class _Gap:
    """A missing seq the consumer is waiting on."""

    first_seen: float
    #: Snapshot xmax once the seq has been missing for
    #: gap_min_wait_seconds: every transaction that could hold it has an
    #: id below this. None until then.
    horizon: int | None = None


class EventConsumer(abc.ABC):
    """Subclass + implement ``handle(batch)``. Construct via
    ``from_env()``, call ``run_forever()``."""

    def __init__(self, config: ConsumerConfig) -> None:
        self.config = config
        self._conn: psycopg.Connection | None = None
        self._labels = {"consumer": config.name}
        self._lag = _EVENT_LAG_SECONDS
        self._processed = _EVENTS_PROCESSED_TOTAL
        self._failed = _EVENTS_FAILED_TOTAL
        self._batch_size = _EVENT_BATCH_SIZE
        # Poison-event detection. When the same first-seq fails
        # max_attempts times in a row, we treat it as poison and skip.
        # Reset on any successful batch or any failure at a different
        # first-seq (so transient errors don't burn the counter).
        self._last_failed_first_seq: int | None = None
        self._consecutive_failures: int = 0
        # Missing seqs being waited on, by seq. In memory on purpose: a
        # restart only means seeing a gap afresh and waiting once more.
        self._gaps: dict[int, _Gap] = {}

    # ── public API ────────────────────────────────────────

    @classmethod
    def from_env(cls, **kwargs):
        cfg = ConsumerConfig(
            name=os.environ["EVENT_CONSUMER_NAME"],
            dsn=os.environ["EVENTS_DATABASE_URL"],
            poll_interval_seconds=float(
                os.environ.get("EVENT_POLL_INTERVAL", "5.0")
            ),
            batch_size=int(os.environ.get("EVENT_BATCH_SIZE", "1000")),
            max_attempts=int(os.environ.get("EVENT_MAX_ATTEMPTS", "5")),
            upstream_consumer=os.environ.get("EVENT_UPSTREAM_CONSUMER"),
            metrics_port=int(os.environ.get("METRICS_PORT", "9100")),
            kuma_push_url=os.environ.get("KUMA_PUSH_URL"),
        )
        return cls(cfg, **kwargs)

    @abc.abstractmethod
    def handle(self, batch: list[EventEnvelope]) -> None:
        """Apply a batch of events. Must be idempotent.

        Raise to trigger retry; events that exceed
        ``max_attempts`` get DLQ'd — unless ``is_retryable`` says
        the failure is the store's fault, in which case the batch
        retries forever and the offset holds.
        """

    def is_retryable(self, exc: Exception) -> bool:
        # pylint: disable=unused-argument
        """Is this failure the downstream store's fault, not the event's?

        Return True for connection refused/reset, timeouts, 5xx, 429 —
        anything where the same event would succeed once the store is
        healthy again. Those must never advance the offset: the event
        log is the only copy, and a skipped event is never re-emitted.

        Default False, which preserves the poison-skip behaviour for
        subclasses that do not classify. Override in consumers that
        talk to a network store.
        """
        return False

    def run_once(self) -> int:
        """Process one batch. Returns rows processed (0 = caught up,
        1 when we skipped a poison event)."""
        events = self._fetch()
        if not events:
            return 0
        self._batch_size.labels(**self._labels).observe(len(events))
        try:
            self.handle(events)
        except Exception as exc:  # pylint: disable=broad-exception-caught
            if self.is_retryable(exc):
                # The store is down, not the event. Hold the offset and
                # let run_forever back off. No dead_letter row: a row
                # per event per retry is noise that never self-heals,
                # and there is nothing for an operator to triage — the
                # batch replays intact when the store returns.
                self._failed.labels(
                    consumer=self.config.name, event_type="_retryable",
                ).inc(len(events))
                logger.warning(
                    "%s: downstream unavailable at seq=%d (%s: %s); "
                    "holding offset and retrying",
                    self.config.name, events[0].seq,
                    type(exc).__name__, exc,
                )
                raise
            self._record_batch_failure(events, exc)
            first_seq = events[0].seq
            if self._last_failed_first_seq == first_seq:
                self._consecutive_failures += 1
            else:
                self._last_failed_first_seq = first_seq
                self._consecutive_failures = 1

            if self._consecutive_failures >= self.config.max_attempts:
                # logger.exception (not .error): the traceback is what a
                # human needs to triage the poison row in events.dead_letter.
                logger.exception(
                    "%s: skipping poison event at seq=%d after %d "
                    "consecutive failures; row stays in "
                    "events.dead_letter for triage.",
                    self.config.name, first_seq,
                    self._consecutive_failures,
                )
                self._commit_offset(first_seq)
                self._reset_failure_state()
                # Skipped event still counts as a "failed" event for
                # the events_failed_total metric — already incremented
                # by _record_batch_failure. Return 1 so run_forever
                # doesn't sleep — keep draining the queue.
                return 1
            raise
        last_seq = events[-1].seq
        self._commit_offset(last_seq)
        self._reset_failure_state()
        for ev in events:
            self._processed.labels(consumer=self.config.name,
                                   event_type=ev.event_type).inc()
        return len(events)

    def _reset_failure_state(self) -> None:
        self._last_failed_first_seq = None
        self._consecutive_failures = 0

    def run_forever(self) -> None:
        if self.config.metrics_port:
            start_http_server(self.config.metrics_port)
        while True:
            try:
                processed = self.run_once()
            except Exception:  # pylint: disable=broad-exception-caught
                logger.exception("consumer iteration failed; retrying")
                processed = 0
                time.sleep(min(self.config.poll_interval_seconds * 2, 60))
            self._heartbeat(ok=True)
            if processed == 0:
                time.sleep(self.config.poll_interval_seconds)

    # ── implementation ────────────────────────────────────

    def _connect(self) -> psycopg.Connection:
        if self._conn is None or self._conn.closed:
            self._conn = psycopg.connect(self.config.dsn, autocommit=False)
        return self._conn

    def _read_offset(self, name: str) -> int:
        cur = self._connect().execute(
            "SELECT last_seq FROM events.consumer_offsets "
            "WHERE consumer_name = %s",
            (name,),
        )
        row = cur.fetchone()
        return int(row[0]) if row else 0

    def _commit_offset(self, last_seq: int) -> None:
        with self._connect().transaction():
            self._connect().execute(
                """
                INSERT INTO events.consumer_offsets
                  (consumer_name, last_seq, updated_at)
                VALUES (%s, %s, now())
                ON CONFLICT (consumer_name) DO UPDATE
                SET last_seq = EXCLUDED.last_seq,
                    updated_at = EXCLUDED.updated_at
                """,
                (self.config.name, last_seq),
            )

    def _fetch(self) -> list[EventEnvelope]:
        offset = self._read_offset(self.config.name)
        upper = None
        if self.config.upstream_consumer:
            upper = self._read_offset(self.config.upstream_consumer)

        sql = (
            "SELECT seq, ts, event_type, schema_version, iri, domain, op, "
            "payload, batch_id, producer "
            "FROM events.entity_events "
            "WHERE seq > %s "
        )
        params: list = [offset]
        if upper is not None:
            sql += "AND seq <= %s "
            params.append(upper)
        sql += "ORDER BY seq LIMIT %s"
        params.append(self.config.batch_size)

        conn = self._connect()
        # Oldest transaction still running, BEFORE the read: a gap whose
        # holders all ended before this point is settled in what we read.
        oldest_running = self._snapshot_bound(conn, "pg_snapshot_xmin")
        rows = conn.execute(sql, params).fetchall()
        # Newest possible holder of a gap seen in this read.
        horizon = self._snapshot_bound(conn, "pg_snapshot_xmax")
        conn.commit()  # release the read txn
        rows = self._contiguous(rows, offset, oldest_running, horizon)

        out = [
            EventEnvelope(
                seq=r[0], ts=r[1], event_type=r[2], schema_version=r[3],
                iri=r[4], domain=r[5], op=r[6], payload=r[7],
                batch_id=r[8], producer=r[9],
            )
            for r in rows
        ]
        # Update lag gauge based on the newest event we know about.
        if out:
            newest_ts = out[-1].ts
            self._lag.labels(**self._labels).set(
                max(0.0, time.time() - newest_ts.timestamp())
            )
        return out

    @staticmethod
    def _snapshot_bound(conn: psycopg.Connection, fn: str) -> int:
        """xmin or xmax of the current snapshot, as a 64-bit xid."""
        return int(conn.execute(
            f"SELECT {fn}(pg_current_snapshot())::text").fetchone()[0])

    def _contiguous(self, rows: list, offset: int, oldest_running: int,
                    horizon: int) -> list:
        """The rows up to the first seq that may still be in flight.

        A missing seq is passed only once it is settled: every
        transaction that could hold it (an id below the horizon taken
        ``gap_min_wait_seconds`` after it was first seen) had ended
        before this read began (``oldest_running`` has moved past it).
        A settled seq was rolled back: had it been committed, this read
        would hold it.
        """
        now = time.monotonic()
        expected = offset + 1
        out = []
        for row in rows:
            seq = row[0]
            if seq != expected and not self._gap_settled(
                    expected, seq, oldest_running, horizon, now):
                break
            out.append(row)
            expected = seq + 1
        self._gaps = {s: g for s, g in self._gaps.items() if s >= expected}
        return out

    def _gap_settled(  # pylint: disable=too-many-arguments,too-many-positional-arguments
        self, first_missing: int, next_seen: int, oldest_running: int,
        horizon: int, now: float,
    ) -> bool:
        gap = self._gaps.setdefault(first_missing, _Gap(first_seen=now))
        waited = now - gap.first_seen
        if waited >= self.config.gap_max_wait_seconds:
            logger.error(
                "%s: seqs %d..%d still missing after %.0fs while older "
                "transactions run; passing them. If one commits later it "
                "will not be read.",
                self.config.name, first_missing, next_seen - 1, waited)
            return True
        if gap.horizon is None:
            if waited >= self.config.gap_min_wait_seconds:
                gap.horizon = horizon
            return False
        if oldest_running >= gap.horizon:
            logger.info("%s: seqs %d..%d were never committed; passing them",
                        self.config.name, first_missing, next_seen - 1)
            return True
        return False

    def _record_batch_failure(
        self, events: Iterable[EventEnvelope], exc: Exception,
    ) -> None:
        # Naive first cut: write all events in the failed batch to
        # the DLQ with attempts=1. A subsequent retry that fails
        # again increments. After max_attempts, the consumer treats
        # the batch as poison and skips past (subclass policy).
        with self._connect().transaction():
            for ev in events:
                self._connect().execute(
                    """
                    INSERT INTO events.dead_letter
                      (seq, consumer, error, attempts, first_failed_at)
                    VALUES (%s, %s, %s, 1, now())
                    ON CONFLICT (seq, consumer) DO UPDATE
                    SET attempts = events.dead_letter.attempts + 1,
                        error    = EXCLUDED.error
                    """,
                    (ev.seq, self.config.name, str(exc)),
                )
                self._failed.labels(consumer=self.config.name,
                                    event_type=ev.event_type).inc()

    def _heartbeat(self, *, ok: bool) -> None:
        if not self.config.kuma_push_url:
            return
        try:
            import urllib.parse
            import urllib.request
            qs = urllib.parse.urlencode({
                "status": "up" if ok else "down",
                "msg": f"{self.config.name}",
                "ping": "",
            })
            url = self.config.kuma_push_url + (
                "&" if "?" in self.config.kuma_push_url else "?"
            ) + qs
            urllib.request.urlopen(url, timeout=5).read()
        except Exception:  # pylint: disable=broad-exception-caught
            logger.debug("kuma heartbeat failed", exc_info=True)
